const ayarlar = {
  TOKEN: "", 
  prefix: "!"
};

module.exports = ayarlar;

